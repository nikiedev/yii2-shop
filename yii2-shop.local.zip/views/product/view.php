<?php

use yii\bootstrap\ActiveForm;
use yii\helpers\Html;
use yii\widgets\DetailView;
use yii\helpers\Url;

/* @var $this yii\web\View */
/* @var $model app\models\Product */

$this->title = $model->title;
$this->params['breadcrumbs'][] = ['label' => 'Products', 'url' => ['/product']];
$this->params['breadcrumbs'][] = $this->title;
?>
<div class="product-view">

    <h1><?= Html::encode($this->title) ?></h1>

    <p>
        <?= Html::a('Update', ['update', 'id' => $model->id], ['class' => 'btn btn-primary']) ?>
        <?= Html::a('Set Photo', ['set-photo', 'id' => $model->id], ['class' => 'btn btn-default']) ?>
        <?= Html::a('Delete', ['delete', 'id' => $model->id], [
            'class' => 'btn btn-danger',
            'data' => [
                'confirm' => 'Are you sure you want to delete this item?',
                'method' => 'post',
            ],
        ]) ?>
    </p>

    <?= DetailView::widget([
        'model' => $model,
        'attributes' => [
            'id',
            'title',
            'description:ntext',
            'photo',
            'price',
            'category_id',
        ],
    ]) ?>

    <div class="row">
        <div class="col-sm-6">
            <div class="product-images">
                <div class="product-main-img">
                    <img src="<?= $model->photo ?>" alt="<?= $model->title ?>">
                </div>
            </div>
        </div>
    </div>

    <div class="product-reviews">
		<? foreach ($reviews as $review): ?>
            Отзыв оставил: <?= $review['user_name']; ?>
            <p>
				<?= $review['review_text']; ?>

            </p>
            <a href="<?= Url::to(['review/update', 'id' => $review['id']]) ?>">Редактировать</a>
		<? endforeach; ?>
    </div>

<!--    <form action="--><?//= Url::to(['review/create']) ?><!--" method="post">-->
<!--        <p><input id="user-name" name="user_name" type="text"></p>-->
<!--        <p><input id="user-email" name="review_text" type="text"></p>-->
<!--        <p><input id="review-text" name="review_text" type="text"></p>-->
<!--        <p><button type="button" id="add-review">Оставить отзыв</button></p>-->
<!--        <input id="product-id" name="product-id" value="--><?//= $product_id ?><!--" type="hidden">-->
<!--        <input id="csrf-key" type="hidden" name="--><?//=Yii::$app->request->csrfParam; ?><!--" value="--><?//=Yii::$app->request->getCsrfToken(); ?><!--" />-->
<!--    </form>-->
	<?php $form = ActiveForm::begin(); ?>

	<?= $form->field($reviewModel, 'user_name') ?>

	<?= $form->field($reviewModel, 'user_email') ?>

	<?= $form->field($reviewModel, 'review_text') ?>

    <p><input id="review-product_id" name="product-id" value="<?= $product_id ?>" type="hidden"></p>
    <p><button type="button" id="add-review">Оставить отзыв</button></p>
<!--    <div class="form-group">-->
<!--		--><?//= Html::submitButton('Отправить', ['class' => 'btn btn-primary']) ?>
<!--    </div>-->

	<?php ActiveForm::end(); ?>
</div>

<?//= $this->registerJsFile('@web/js/custom.js', ['position' => \yii\web\View::POS_END]); ?>


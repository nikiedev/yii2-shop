(function ($) {
    var userName, userEmail, productId, reviewText, csrfKey;
    var btnAddReview = $('#add-review');
    var appComment = $('.product-reviews');

    function addComment()
    {

        userName = $('#review-user_name').val();
        userEmail = $('#review-user_email').val();
        productId = $('#review-product_id').val();

        reviewText = $('#review-review_text').val();
        //csrfKey = $('#review-csrf_key').val();

console.log(userName);
        $.ajax({
            url: '/review/create',
            method: 'post',
            data: {
                'userName': userName,
                'reviewText': reviewText,
                'userEmail': userEmail,
                'productId': productId
                //'_csrf': csrfKey
            },
            success: function (data) {
                // $.each(data, function(i, val) {
                if (data) {
                    appComment.append('<p>Отзыв оставил: ' + userName + '</p>');
                }
                //
                // });
                console.log(data);
            }
        });
    }


    btnAddReview.on('click', addComment);
})(jQuery);